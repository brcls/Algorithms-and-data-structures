char* Substitui(char* frase, char* acha, char* troca);
char* Aloca(char* palavra, int n);
void Escreve();
void Imprimir(char *frase);
